package del.ac.id.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HappyTravellingApplication {

	public static void main(String[] args) {
		SpringApplication.run(HappyTravellingApplication.class, args);
	}

}
